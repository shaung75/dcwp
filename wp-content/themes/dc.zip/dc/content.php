<div class="home-txt">
	<?php the_content(); ?>
</div>