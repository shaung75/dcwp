<section class="banner flexslider">
  <ul class="slides">
    <li><img src="<?php echo get_bloginfo('template_directory'); ?>/img/banner1.png" /></li>
  </ul>
</section>